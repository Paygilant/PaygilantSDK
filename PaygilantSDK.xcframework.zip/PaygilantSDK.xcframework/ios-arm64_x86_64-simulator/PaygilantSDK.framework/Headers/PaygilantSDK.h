//
//  PaygilantSDK.h
//  PaygilantSDK
//
//  Created by np on 10/10/2018.
//  Copyright © 2018 Paygilant. All rights reserved.
//

#import <UIKit/UIKit.h>
//#include<zlib.h>

//! Project version number for PaygilantSDK.
FOUNDATION_EXPORT double PaygilantSDKVersionNumber;

//! Project version string for PaygilantSDK.
FOUNDATION_EXPORT const unsigned char PaygilantSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PaygilantSDK/PublicHeader.h>


